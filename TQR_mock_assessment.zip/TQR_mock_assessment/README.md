# MVP of a Movie Collection Management App

## Introduction
Your friend John, who is a front-end developer, asked you to create an [MVP](https://en.wikipedia.org/wiki/Minimum_viable_product) 
of a movie collection management application with REST API. 
As he knows Python well and is a big fan of [TDD](https://en.wikipedia.org/wiki/Test-driven_development), 
he formulated a large part of his expectations in the form of test questions. 
There is also an app skeleton, but your friend, the developer, does not know much about FastAPI,
so he struggled with the implementation of some of the functionalities.

## Problem Statement
  1. Make tests pass by implementing the missing features.
  2. When completing the tasks described below, write your code in the following files: `movie_collector/movie_collector.py` and `movie_collector/schemas.py`.
  3. The functions that have to be implemented have specified HTTP methods in decorators. However, they have some "default" implementation, but it's not obligatory and can be removed.
  4. As it is an MVP, do not use a "real" database, just store the records in a predefined `movies` dict.

### Task 1
**Implement the `list_movies` path operation function.**

It should return a list of movies in such format:
```json
[
  {
    "id": 1,
    "title": "Some title",
    "rating": 3,
    "year": 2012,
    "genre": "Thriller"
  },
  …
]
```

### Task 2
**Configure path routes for `movie_details`, `modify_movie` and `delete_movie` path operation function.**

The routes decorators are commented out as they are incorrect. Uncomment them and configure according to the following requirements.
The path operation function should accept the movie ID as an argument. Please make sure that the route will accept a trailing slash (/), i.e. `1` and `1/` will both be correct.

### Task 3
**Implement the `movie_details` path operation function.**

It should return the data related to a single movie selected with a movie ID passed by URL. The expected format is:
```json
{
  "id": 1,
  "title": "Some title",
  "rating": 3,
  "year": 2012,
  "genre": "Thriller"
}
```
If a movie with a given ID does not exist, it should return the 404 code and the following json content: `{"detail": "Not Found"}`.

### Task 4
**Implement the `delete_movie` path operation function.**

It should remove a movie with an ID argument passed by URL and respond with the 204 code (no content). 
Similarly to the `movie_details`, if a movie with a given ID does not exist, return the 404 code with the same content.

### Task 5
**Implement the `create_movie` path operation function.**

It should create a new movie entry. The ID for the created movie should be assigned automatically from a sequence of integer numbers, starting from 1. 
This function should only accept the following fields: `title`, `rating`, `year`, `genre`.
There should be a validation of the `rating` field, that is only integers from 1 to 5 are acceptable as ratings. 
In case of an invalid request, e.g. a missing field or a typo in the field name, the function should return default validation error from `pydantic` model
message with the 422 error code and, of course, should not save that record.

### Task 6
**Implement the `modify_movie` path operation function.**

It should update an existing movie with the data sent by the user (`PUT` request). 
The user should be able to send one or more properties of a movie specified by the `ID` argument passed by URL. 
An ID change is forbidden. The function should return the 422 code with the same message as in the `create_movie` function in the following cases:
  * The user sends nothing.
  * The user passes the values of wrong/invalid types.

If a movie specified by the ID argument passed by URL does not exist, the function should return the 404 code with the same message as in `movie_details` and `delete_movie` path operation functions.

### Task 7
**Make the `list_movies` path operation function orderable and pageable.**

There should be a possibility to order the results and those results should be paginated.

For pagination, there is an imposed page size, and it consists of 10 records. 
The first page should be set as the default one (when you enter the list through the `/` path). 
All pages should be available through the GET argument `page`, e.g. path `/?page=2` should take the user to the second page. 
If the user passes a number of a page that does not exist, just return them an empty list.

The results should be orderable by `rating`, `ID` and `title` (fyi, `PossibleOrdering` variable).
The ordering key should be passed similarly as the page, through the GET argument `ordering`, an example path would be `/?ordering=id`.
We only want to sort the results in an ascending order and by only one column at a time.

Of course, it should be possible to select both `page` and `ordering` at once, for example, by using `/?page=2&ordering=title`.

## Hints
  1. You should not modify the code outside of the mentioned places.
  2. You can import the required dependencies from FastAPI and a standard library.

To execute all unit tests, use:

    pip install -e . && pytest
