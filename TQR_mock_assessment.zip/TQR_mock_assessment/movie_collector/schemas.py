import typing

from pydantic import BaseModel, Field, ConfigDict, conint


class Movie(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    rating: int
    year: int
    genre: str
