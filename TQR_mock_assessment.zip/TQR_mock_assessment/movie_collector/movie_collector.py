import typing

from fastapi import FastAPI

from .schemas import Movie


app = FastAPI()

movies = {}
PossibleOrdering = typing.Literal["id", "title", "rating"]


@app.get("/")
def list_movies():
    """TODO: Task 1 & 7"""


@app.post("/")
def create_movie():
    """TODO: Task 5"""


# @app.get('')
def movie_details():
    """TODO: Task 3"""


# @app.put('')
def modify_movie():
    """TODO: Task 6"""


# @app.delete('')
def delete_movie():
    """TODO: Task 4"""
