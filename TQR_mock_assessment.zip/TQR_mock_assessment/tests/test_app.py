import copy
from unittest import TestCase

from fastapi.testclient import TestClient

from movie_collector.movie_collector import app, movies


class BaseAppTestCase(TestCase):
    VALID_MOVIES = [
        {
            "id": 1,
            "title": "Some title",
            "genre": "Sci-Fi",
            "year": 2010,
            "rating": 3,
        },
        {
            "id": 2,
            "title": "Another title",
            "genre": "Comedy",
            "year": 2008,
            "rating": 4,
        },
        {
            "id": 4,
            "title": "Pretty new",
            "genre": "Drama",
            "year": 2019,
            "rating": 2,
        },
    ]

    def setUp(self):
        movies.clear()
        self.app = app
        self.test_client = TestClient(self.app)

    def insert_valid_movies(self):
        for movie in self.VALID_MOVIES:
            movies[movie["id"]] = copy.deepcopy(movie)

    def insert_random_movies(self, quantity=25):
        for i in range(1, quantity + 1):
            movies[i] = {
                "id": i,
                "title": "Title {}".format(i),
                "genre": "Drama",
                "year": 1970 + i,
                "rating": i % 5 + 1,
            }

    def assert_equal_omitting_id(self, d1, d2):
        return self.assertEqual(
            {k: v for k, v in d1.items() if k != "id"},
            {k: v for k, v in d2.items() if k != "id"},
        )


class MovieListTestCase(BaseAppTestCase):
    def test_index_page_default(self):
        self.insert_valid_movies()

        response = self.test_client.get("/")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 3)
        self.assertEqual(len(movies), 3)
        self.assertEqual(data[0], self.VALID_MOVIES[0])
        self.assertEqual(data[1], self.VALID_MOVIES[1])
        self.assertEqual(data[2], self.VALID_MOVIES[2])

    def test_index_ordered_by_rating(self):
        self.insert_valid_movies()

        response = self.test_client.get("/?ordering=rating")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 3)
        self.assertEqual(len(movies), 3)
        self.assertEqual(data[0], self.VALID_MOVIES[2])
        self.assertEqual(data[1], self.VALID_MOVIES[0])
        self.assertEqual(data[2], self.VALID_MOVIES[1])

    def test_index_paginated_first_page_by_default(self):
        self.insert_random_movies(25)

        response = self.test_client.get("/")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 10)
        self.assertEqual(len(movies), 25)
        self.assertEqual(list(movies.values())[:10], data)

    def test_index_paginated_second_page(self):
        self.insert_random_movies(25)

        response = self.test_client.get("/?page=2")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 10)
        self.assertEqual(len(movies), 25)
        self.assertEqual(list(movies.values())[10:20], data)


class MovieCreationTestCase(BaseAppTestCase):
    def test_creating_movie(self):
        valid_movie_data = self.VALID_MOVIES[0]

        response = self.test_client.post(
            "/",
            json={k: v for k, v in valid_movie_data.items() if k != "id"},
        )

        self.assertEqual(response.status_code, 201, response.content)
        self.assert_equal_omitting_id(response.json(), valid_movie_data)
        self.assertEqual(len(movies), 1)

    def test_creating_movie_with_missing_fields(self):
        response = self.test_client.post("/", json={"title": "Some Title"})

        self.assertEqual(response.status_code, 422, response.content)
        self.assertIn(b"missing", response.content)
        self.assertEqual(len(movies), 0)


class MovieDetailsTestCase(BaseAppTestCase):
    def test_movie_details(self):
        self.insert_valid_movies()

        response = self.test_client.get("/1/")

        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json(), self.VALID_MOVIES[0])
        self.assertEqual(len(movies), 3)

    def test_movie_details_not_found(self):
        self.insert_valid_movies()

        response = self.test_client.get("/100", follow_redirects=True)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"detail": "Not Found"})
        self.assertEqual(len(movies), 3)


class MovieModificationTestCase(BaseAppTestCase):
    def test_modifying_movie_title(self):
        self.insert_valid_movies()
        valid_movie_data = self.VALID_MOVIES[0]
        new_title = "Totally New Title"

        response = self.test_client.put(
            "/1/",
            json={
                "title": new_title,
                "genre": "Sci-Fi",
                "year": 2010,
                "rating": 3,
            },
        )

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        for field_name in ["genre", "year", "rating"]:
            self.assertEqual(data[field_name], valid_movie_data[field_name])
            self.assertEqual(getattr(movies[1], field_name), valid_movie_data[field_name])
        self.assertEqual(data["title"], new_title)
        self.assertEqual(movies[1].title, new_title)
        self.assertEqual(len(movies), 3)

    def test_modifying_movie_with_too_big_rating(self):
        self.insert_valid_movies()
        valid_movie_data = self.VALID_MOVIES[0]

        response = self.test_client.put(
            "/1/",
            json={
                "title": valid_movie_data["title"],
                "genre": valid_movie_data["genre"],
                "year": valid_movie_data["year"],
                "rating": 10,
            },
        )

        self.assertEqual(response.status_code, 422, response.content)
        self.assertIn(b"less_than", response.content)
        self.assertEqual(len(movies), 3)

    def test_modifying_non_existent_movie(self):
        response = self.test_client.put(
            "/1/",
            json={
                "title": "2012",
                "genre": "Drama",
                "year": 2000,
                "rating": 4,
            },
        )

        self.assertEqual(response.status_code, 404, response.content)
        self.assertEqual(response.json(), {"detail": "Not Found"})
        self.assertEqual(len(movies), 0)


class MovieDeletionTestCase(BaseAppTestCase):
    def test_deleting_movie(self):
        self.insert_valid_movies()

        response = self.test_client.delete("/1/")

        self.assertEqual(response.status_code, 204)
        self.assertEqual(response.content, b"")
        self.assertEqual(len(movies), 2)

    def test_deleting_non_existent_movie(self):
        self.insert_valid_movies()

        response = self.test_client.get("/100", follow_redirects=True)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"detail": "Not Found"})
        self.assertEqual(len(movies), 3)
