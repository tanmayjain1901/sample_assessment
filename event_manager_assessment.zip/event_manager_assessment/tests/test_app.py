import copy
from unittest import TestCase

from fastapi.testclient import TestClient

from event_manager.event_manager import app, events


class BaseEventTestCase(TestCase):
    VALID_EVENTS = [
        {
            "id": 1,
            "title": "Python Conference 2026",
            "description": "Annual Python conference",
            "category": "Conference",
            "date": "2026-06-15",
            "location": "San Francisco",
            "capacity": 500,
            "registered_count": 0,
            "status": "open",
        },
        {
            "id": 2,
            "title": "Web Development Workshop",
            "description": "Learn FastAPI and React",
            "category": "Workshop",
            "date": "2026-05-20",
            "location": "New York",
            "capacity": 50,
            "registered_count": 0,
            "status": "open",
        },
        {
            "id": 3,
            "title": "Data Science Meetup",
            "description": "Monthly data science discussion",
            "category": "Meetup",
            "date": "2026-07-10",
            "location": "Boston",
            "capacity": 100,
            "registered_count": 0,
            "status": "closed",
        },
    ]

    def setUp(self):
        events.clear()
        self.app = app
        self.test_client = TestClient(self.app)

    def insert_valid_events(self):
        for event in self.VALID_EVENTS:
            events[event["id"]] = copy.deepcopy(event)

    def insert_random_events(self, quantity=25):
        for i in range(1, quantity + 1):
            events[i] = {
                "id": i,
                "title": f"Event {i}",
                "description": f"Description for event {i}",
                "category": "Conference" if i % 2 == 0 else "Meetup",
                "date": f"2026-{(i % 12) + 1:02d}-{(i % 28) + 1:02d}",
                "location": f"City {i % 5}",
                "capacity": 100 + (i * 10),
                "registered_count": 0,
                "status": "open" if i % 3 != 0 else "closed",
            }


class EventListTestCase(BaseEventTestCase):
    def test_list_events_default(self):
        """Task 1: List events without filters"""
        self.insert_valid_events()

        response = self.test_client.get("/")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 3)
        self.assertEqual(len(events), 3)
        self.assertEqual(data[0], self.VALID_EVENTS[0])
        self.assertEqual(data[1], self.VALID_EVENTS[1])
        self.assertEqual(data[2], self.VALID_EVENTS[2])

    def test_list_events_sorted_by_date(self):
        """Task 8: Sort events by date"""
        self.insert_valid_events()

        response = self.test_client.get("/?sort_by=date")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 3)
        # Events should be sorted by date in ascending order
        self.assertEqual(data[0]["date"], "2026-05-20")  # Workshop
        self.assertEqual(data[1]["date"], "2026-06-15")  # Conference
        self.assertEqual(data[2]["date"], "2026-07-10")  # Meetup

    def test_list_events_sorted_by_title(self):
        """Task 8: Sort events by title"""
        self.insert_valid_events()

        response = self.test_client.get("/?sort_by=title")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 3)
        # Events should be sorted by title alphabetically
        self.assertEqual(data[0]["title"], "Data Science Meetup")
        self.assertEqual(data[1]["title"], "Python Conference 2026")
        self.assertEqual(data[2]["title"], "Web Development Workshop")

    def test_list_events_filter_by_category(self):
        """Task 8: Filter events by category"""
        self.insert_valid_events()

        response = self.test_client.get("/?category=Conference")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["id"], 1)
        self.assertEqual(data[0]["category"], "Conference")

    def test_list_events_filter_by_status(self):
        """Task 8: Filter events by status"""
        self.insert_valid_events()

        response = self.test_client.get("/?status=open")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 2)
        for event in data:
            self.assertEqual(event["status"], "open")

    def test_list_events_pagination_first_page(self):
        """Task 8: Pagination - first page by default"""
        self.insert_random_events(25)

        response = self.test_client.get("/")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 10)
        self.assertEqual(len(events), 25)

    def test_list_events_pagination_second_page(self):
        """Task 8: Pagination - second page"""
        self.insert_random_events(25)

        response = self.test_client.get("/?page=2")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 10)
        self.assertEqual(len(events), 25)

    def test_list_events_pagination_non_existent_page(self):
        """Task 8: Pagination - non-existent page returns empty list"""
        self.insert_random_events(25)

        response = self.test_client.get("/?page=999")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(len(data), 0)

    def test_list_events_combined_filters_and_pagination(self):
        """Task 8: Combined filters, sorting, and pagination"""
        self.insert_random_events(25)

        response = self.test_client.get("/?category=Conference&status=open&sort_by=title&page=1")

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        # Should have some results with category=Conference and status=open
        for event in data:
            self.assertEqual(event["category"], "Conference")
            self.assertEqual(event["status"], "open")


class EventCreationTestCase(BaseEventTestCase):
    def test_create_event(self):
        """Task 5: Create a new event"""
        event_data = {
            "title": "Python Conference 2026",
            "description": "Annual Python conference",
            "category": "Conference",
            "date": "2026-06-15",
            "location": "San Francisco",
            "capacity": 500,
        }

        response = self.test_client.post("/", json=event_data)

        self.assertEqual(response.status_code, 201, response.content)
        data = response.json()
        self.assertEqual(data["title"], event_data["title"])
        self.assertEqual(data["registered_count"], 0)
        self.assertEqual(data["status"], "open")
        self.assertEqual(data["id"], 1)
        self.assertEqual(len(events), 1)

    def test_create_event_auto_increment_id(self):
        """Task 5: IDs are auto-incremented"""
        self.insert_valid_events()
        
        event_data = {
            "title": "New Event",
            "description": "A new event",
            "category": "Workshop",
            "date": "2026-08-01",
            "location": "Chicago",
            "capacity": 75,
        }

        response = self.test_client.post("/", json=event_data)

        self.assertEqual(response.status_code, 201, response.content)
        data = response.json()
        self.assertEqual(data["id"], 4)  # Should be next ID

    def test_create_event_with_missing_fields(self):
        """Task 5: Missing required fields returns 422"""
        response = self.test_client.post("/", json={"title": "Incomplete Event"})

        self.assertEqual(response.status_code, 422, response.content)
        self.assertIn(b"missing", response.content)
        self.assertEqual(len(events), 0)

    def test_create_event_with_invalid_capacity(self):
        """Task 5: Invalid capacity (non-positive) returns 422"""
        event_data = {
            "title": "Bad Event",
            "description": "Invalid capacity",
            "category": "Conference",
            "date": "2026-06-15",
            "location": "San Francisco",
            "capacity": 0,  # Invalid
        }

        response = self.test_client.post("/", json=event_data)

        self.assertEqual(response.status_code, 422, response.content)

    def test_create_event_with_excessive_capacity(self):
        """Task 5: Capacity exceeding limit returns 422"""
        event_data = {
            "title": "Huge Event",
            "description": "Too many capacity",
            "category": "Conference",
            "date": "2026-06-15",
            "location": "San Francisco",
            "capacity": 50001,  # Exceeds limit of 10000
        }

        response = self.test_client.post("/", json=event_data)

        self.assertEqual(response.status_code, 422, response.content)


class EventDetailsTestCase(BaseEventTestCase):
    def test_event_details(self):
        """Task 3: Get event details by ID"""
        self.insert_valid_events()

        response = self.test_client.get("/1/")

        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json(), self.VALID_EVENTS[0])
        self.assertEqual(len(events), 3)

    def test_event_details_without_trailing_slash(self):
        """Task 3: GET /1 should also work (without trailing slash)"""
        self.insert_valid_events()

        response = self.test_client.get("/1")

        self.assertEqual(response.status_code, 200, response.content)
        self.assertEqual(response.json(), self.VALID_EVENTS[0])

    def test_event_details_not_found(self):
        """Task 3: Non-existent event returns 404"""
        self.insert_valid_events()

        response = self.test_client.get("/999", follow_redirects=True)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"detail": "Not Found"})
        self.assertEqual(len(events), 3)


class EventUpdateTestCase(BaseEventTestCase):
    def test_update_event_single_field(self):
        """Task 6: Update single field of an event"""
        self.insert_valid_events()
        original_event = self.VALID_EVENTS[0]
        new_title = "Updated Conference Title"

        response = self.test_client.put(
            "/1/",
            json={"title": new_title},
        )

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(data["title"], new_title)
        self.assertEqual(data["description"], original_event["description"])
        self.assertEqual(data["id"], 1)

    def test_update_event_multiple_fields(self):
        """Task 6: Update multiple fields"""
        self.insert_valid_events()

        response = self.test_client.put(
            "/1/",
            json={
                "title": "New Title",
                "location": "New Location",
                "capacity": 600,
            },
        )

        self.assertEqual(response.status_code, 200, response.content)
        data = response.json()
        self.assertEqual(data["title"], "New Title")
        self.assertEqual(data["location"], "New Location")
        self.assertEqual(data["capacity"], 600)

    def test_update_event_invalid_capacity(self):
        """Task 6: Invalid capacity returns 422"""
        self.insert_valid_events()

        response = self.test_client.put(
            "/1/",
            json={"capacity": 0},
        )

        self.assertEqual(response.status_code, 422, response.content)

    def test_update_event_no_fields(self):
        """Task 6: No fields provided returns 422"""
        self.insert_valid_events()

        response = self.test_client.put("/1/", json={})

        self.assertEqual(response.status_code, 422, response.content)

    def test_update_non_existent_event(self):
        """Task 6: Updating non-existent event returns 404"""
        response = self.test_client.put(
            "/1/",
            json={"title": "New Title"},
        )

        self.assertEqual(response.status_code, 404, response.content)
        self.assertEqual(response.json(), {"detail": "Not Found"})


class EventDeletionTestCase(BaseEventTestCase):
    def test_delete_event(self):
        """Task 4: Delete an event"""
        self.insert_valid_events()

        response = self.test_client.delete("/1/")

        self.assertEqual(response.status_code, 204)
        self.assertEqual(response.content, b"")
        self.assertEqual(len(events), 2)

    def test_delete_event_without_trailing_slash(self):
        """Task 4: DELETE /1 should also work"""
        self.insert_valid_events()

        response = self.test_client.delete("/1")

        self.assertEqual(response.status_code, 204)
        self.assertEqual(len(events), 2)

    def test_delete_non_existent_event(self):
        """Task 4: Deleting non-existent event returns 404"""
        self.insert_valid_events()

        response = self.test_client.delete("/999", follow_redirects=True)

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"detail": "Not Found"})
        self.assertEqual(len(events), 3)


class AttendeeRegistrationTestCase(BaseEventTestCase):
    def test_register_attendee(self):
        """Task 7: Register an attendee to an event"""
        self.insert_valid_events()
        event = self.VALID_EVENTS[0]

        response = self.test_client.post(
            "/1/register",
            json={"name": "John Doe", "email": "john@example.com"},
        )

        self.assertEqual(response.status_code, 201, response.content)
        data = response.json()
        self.assertEqual(data["registered_count"], 1)
        self.assertEqual(events[1]["registered_count"], 1)

    def test_register_multiple_attendees(self):
        """Task 7: Register multiple attendees"""
        self.insert_valid_events()

        for i in range(3):
            response = self.test_client.post(
                "/1/register",
                json={"name": f"Person {i}", "email": f"person{i}@example.com"},
            )
            self.assertEqual(response.status_code, 201)

        self.assertEqual(events[1]["registered_count"], 3)

    def test_register_attendee_event_full(self):
        """Task 7: Registration fails when event is at capacity"""
        # Create an event with capacity=2
        event_data = {
            "title": "Small Event",
            "description": "Limited seats",
            "category": "Workshop",
            "date": "2026-05-20",
            "location": "Boston",
            "capacity": 2,
        }
        response = self.test_client.post("/", json=event_data)
        event_id = response.json()["id"]

        # Register 2 attendees (fill capacity)
        for i in range(2):
            self.test_client.post(
                f"/{event_id}/register",
                json={"name": f"Person {i}", "email": f"person{i}@example.com"},
            )

        # Try to register 3rd attendee
        response = self.test_client.post(
            f"/{event_id}/register",
            json={"name": "Person 3", "email": "person3@example.com"},
        )

        self.assertEqual(response.status_code, 400, response.content)
        self.assertEqual(response.json(), {"detail": "Event is at full capacity"})

    def test_register_attendee_event_not_found(self):
        """Task 7: Registration to non-existent event returns 404"""
        response = self.test_client.post(
            "/999/register",
            json={"name": "John Doe", "email": "john@example.com"},
        )

        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.json(), {"detail": "Not Found"})

    def test_register_attendee_invalid_email(self):
        """Task 7: Invalid email format returns 422"""
        self.insert_valid_events()

        response = self.test_client.post(
            "/1/register",
            json={"name": "John Doe", "email": "not-an-email"},
        )

        self.assertEqual(response.status_code, 422, response.content)
