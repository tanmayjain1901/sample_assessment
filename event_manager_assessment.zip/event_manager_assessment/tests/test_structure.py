import base64
import unittest

import event_manager.event_manager


class StructureTestSuite(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.MODULE = event_manager.event_manager

    def test_function_exists_list_events(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'bGlzdF9ldmVudHM=').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'bGlzdF9ldmVudHM=').decode()}` "
                f"is not found, but it was marked as required."
        )

    def test_function_exists_create_event(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'Y3JlYXRlX2V2ZW50').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'Y3JlYXRlX2V2ZW50').decode()}` "
                f"is not found, but it was marked as required."
        )

    def test_function_exists_event_details(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'ZXZlbnRfZGV0YWlscw==').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'ZXZlbnRfZGV0YWlscw==').decode()}` "
                f"is not found, but it was marked as required."
        )

    def test_function_exists_update_event(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'dXBkYXRlX2V2ZW50').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'dXBkYXRlX2V2ZW50').decode()}` "
                f"is not found, but it was marked as required."
        )

    def test_function_exists_delete_event(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'ZGVsZXRlX2V2ZW50').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'ZGVsZXRlX2V2ZW50').decode()}` "
                f"is not found, but it was marked as required."
        )

    def test_function_exists_register_attendee(self):
        functions = _get_function_names(self.MODULE)
        self.assertIn(
            base64.b64decode(b'cmVnaXN0ZXJfYXR0ZW5kZWU=').decode(),
            functions,
            msg=f"The function "
                f"`{base64.b64decode(b'cmVnaXN0ZXJfYXR0ZW5kZWU=').decode()}` "
                f"is not found, but it was marked as required."
        )


# === Internal functions, do not modify ===
import inspect

from types import ModuleType
from typing import List


def _get_function_names(module: ModuleType) -> List[str]:
    names = []
    functions = inspect.getmembers(module, lambda member: inspect.isfunction(member))
    for name, fn in functions:
        if fn.__module__ == module.__name__:
            names.append(name)
    return names


def _get_function_arg_names(module: ModuleType, fn_name: str) -> List[str]:
    arg_names = []
    functions = inspect.getmembers(module, lambda member: inspect.isfunction(member))
    for name, fn in functions:
        if fn.__module__ == module.__name__:
            if fn.__qualname__ == fn_name:
                args_spec = inspect.getfullargspec(fn)
                arg_names = args_spec.args
                if args_spec.varargs is not None:
                    arg_names.extend(args_spec.varargs)
                if args_spec.varkw is not None:
                    arg_names.extend(args_spec.varkw)
                arg_names.extend(args_spec.kwonlyargs)
                break
    return arg_names


def _get_class_names(module: ModuleType) -> List[str]:
    names = []
    classes = inspect.getmembers(module, lambda member: inspect.isclass(member))
    for name, cls in classes:
        if cls.__module__ == module.__name__:
            names.append(name)
    return names
