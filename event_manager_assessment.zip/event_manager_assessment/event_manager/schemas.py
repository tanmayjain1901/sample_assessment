import typing
from pydantic import BaseModel, Field, ConfigDict


class Event(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: str
    category: str
    date: str  # Format: YYYY-MM-DD
    location: str
    capacity: int
    registered_count: int
    status: str


class EventCreate(BaseModel):
    """Schema for creating a new event (without id, registered_count, status)"""
    title: str
    description: str
    category: str
    date: str
    location: str
    capacity: int = Field(..., gt=0, le=10000)


class EventUpdate(BaseModel):
    """Schema for updating an event (all fields optional)"""
    title: str | None = None
    description: str | None = None
    category: str | None = None
    date: str | None = None
    location: str | None = None
    capacity: int | None = Field(None, gt=0, le=10000)


class AttendeeRegistration(BaseModel):
    """Schema for registering an attendee"""
    name: str
    email: str
