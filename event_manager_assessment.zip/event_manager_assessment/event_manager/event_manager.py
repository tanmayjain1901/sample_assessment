import typing

from fastapi import FastAPI

from .schemas import Event, EventCreate, EventUpdate, AttendeeRegistration


app = FastAPI()

events = {}
PossibleOrdering = typing.Literal["id", "title", "date", "capacity"]


@app.get("/")
def list_events():
    """TODO: Task 1 & 8"""


@app.post("/")
def create_event():
    """TODO: Task 5"""


# @app.get('')
def event_details():
    """TODO: Task 3"""


# @app.put('')
def update_event():
    """TODO: Task 6"""


# @app.delete('')
def delete_event():
    """TODO: Task 4"""


# @app.post('')
def register_attendee():
    """TODO: Task 7"""
